import { combineReducers } from "redux"
import customizer from "./customizer"

const customizerReducer = combineReducers({
  customizer
})

export default customizerReducer
